
            //2.1
            window.alert("Welcome to 2.1, my name is Matt.");

            //2.2
            console.log("My favorite food is chicken stir fry.");

            //2.3
            window.prompt("What is your favorite color?")

            //2.4
            window.confirm("Please close this button.");

    //VARIABLES

    //3.1
    let favnumber=42;

    //3.2
    let isfalse=false;

    //3.3
    let favcolor="Royal BLue";

    //3.4
    let total=1115+305;

    //3.5
    let isfivegreater=5>3;

    //3.6
    let h1tag="<h1> Ummm... I think I'm doing this right... maybe?</h1>";

    
    //4.1
    let firstName="Matthew ";

    //4.2
    let lastName="Roddy";

    //4.3
    let term=3;

    //4.4
    let fullName=(firstName + lastName);

    //4.5
    let currentMessage="Hello my name is " + fullName + " I am in quarter " + term;

    //4.6
    let futureMessage="I will graduate in " + (8 - term) + " quarters";





    


